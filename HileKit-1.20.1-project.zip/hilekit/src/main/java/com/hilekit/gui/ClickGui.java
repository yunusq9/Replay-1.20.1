package com.hilekit.gui;

import com.hilekit.HileKit;
import com.hilekit.module.Module;
import com.hilekit.module.Setting;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.SliderWidget;
import net.minecraft.text.Text;

import java.util.HashSet;
import java.util.Set;

public class ClickGui extends Screen {
    private final Set<Module> expanded = new HashSet<>();

    public ClickGui() {
        super(Text.literal("HileKit"));
    }

    @Override
    protected void init() {
        int x = width / 2 - 100;
        int y = 30;
        for (Module m : HileKit.modules.all) {
            addDrawableChild(ButtonWidget.builder(label(m), b -> {
                m.toggle();
                b.setMessage(label(m));
            }).dimensions(x, y, 170, 20).build());
            addDrawableChild(ButtonWidget.builder(Text.literal("⚙"), b -> {
                if (!expanded.remove(m)) expanded.add(m);
                clearChildren();
                init();
            }).dimensions(x + 174, y, 26, 20).build());
            y += 24;
            if (expanded.contains(m)) {
                for (Setting s : m.settings) {
                    addDrawableChild(new Slider(x + 10, y, 180, 18, s));
                    y += 21;
                }
            }
        }
    }

    private Text label(Module m) {
        return Text.literal(m.name + ": " + (m.enabled ? "§aAÇIK" : "§cKAPALI"));
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        renderBackground(context);
        context.drawCenteredTextWithShadow(textRenderer, "HileKit", width / 2, 12, 0xFFFFFF);
        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    private static class Slider extends SliderWidget {
        private final Setting s;

        Slider(int x, int y, int w, int h, Setting s) {
            super(x, y, w, h, Text.empty(), (s.value - s.min) / (s.max - s.min));
            this.s = s;
            updateMessage();
        }

        @Override
        protected void updateMessage() {
            setMessage(Text.literal(s.name + ": " + String.format("%.2f", s.value)));
        }

        @Override
        protected void applyValue() {
            s.value = s.min + value * (s.max - s.min);
        }
    }
}

package com.hilekit;

import java.util.Collections;
import java.util.Set;
import java.util.TreeSet;

public class FriendManager {
    private static final Set<String> friends = Collections.synchronizedSet(new TreeSet<>(String.CASE_INSENSITIVE_ORDER));

    public static boolean add(String name) {
        return friends.add(name);
    }

    public static boolean remove(String name) {
        return friends.remove(name);
    }

    public static boolean isFriend(String name) {
        return friends.contains(name);
    }

    public static Set<String> all() {
        return friends;
    }
}

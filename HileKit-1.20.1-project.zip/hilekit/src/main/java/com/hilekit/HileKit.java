package com.hilekit;

import com.hilekit.gui.ClickGui;
import com.hilekit.module.Modules;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.message.v1.ClientSendMessageEvents;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import org.lwjgl.glfw.GLFW;

public class HileKit implements ClientModInitializer {
    public static final Modules modules = new Modules();
    private static KeyBinding menuKey;

    @Override
    public void onInitializeClient() {
        menuKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "HileKit Menü", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT, "HileKit"));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (menuKey.wasPressed()) {
                client.setScreen(new ClickGui());
            }
            if (client.player != null && client.world != null) modules.tick();
        });

        AttackEntityCallback.EVENT.register((player, world, hand, entity, hit) -> {
            if (world.isClient && modules.noFriendsDamage.enabled && entity instanceof PlayerEntity p
                    && FriendManager.isFriend(p.getGameProfile().getName())) {
                return ActionResult.FAIL;
            }
            return ActionResult.PASS;
        });

        ClientSendMessageEvents.ALLOW_CHAT.register(message -> {
            if (!message.startsWith(".frend")) return true;
            String[] a = message.trim().split("\\s+");
            MinecraftClient mc = MinecraftClient.getInstance();
            if (a.length >= 3 && a[1].equalsIgnoreCase("add")) {
                FriendManager.add(a[2]);
                say(mc, "§a" + a[2] + " arkadaş listesine eklendi.");
            } else if (a.length >= 3 && a[1].equalsIgnoreCase("remove")) {
                FriendManager.remove(a[2]);
                say(mc, "§e" + a[2] + " arkadaş listesinden çıkarıldı.");
            } else if (a.length >= 2 && a[1].equalsIgnoreCase("list")) {
                say(mc, "§bArkadaşlar: " + String.join(", ", FriendManager.all()));
            } else {
                say(mc, "§7Kullanım: .frend add <oyuncu> | remove <oyuncu> | list");
            }
            return false;
        });
    }

    private static void say(MinecraftClient mc, String s) {
        if (mc.player != null) mc.player.sendMessage(Text.literal(s), false);
    }
}

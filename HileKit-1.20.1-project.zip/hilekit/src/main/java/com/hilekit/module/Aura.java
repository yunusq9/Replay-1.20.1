package com.hilekit.module;

import net.minecraft.entity.Entity;

public class Aura extends Module {
    public final Setting range = add("Menzil", 2, 6, 3.5);
    public final Setting cooldown = add("Bekleme", 0.5, 1.0, 0.95);

    public Aura() {
        super("Aura");
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null || mc.currentScreen != null) return;
        if (mc.player.getAttackCooldownProgress(0.5f) < cooldown.value) return;
        Entity t = Util.nearest(mc, range.value, false);
        if (t != null) Util.attack(mc, t);
    }
}

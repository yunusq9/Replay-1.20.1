package com.hilekit.module;

import java.util.List;

public class Modules {
    public final AimAssist aimAssist = new AimAssist();
    public final TriggerBot triggerBot = new TriggerBot();
    public final Aura aura = new Aura();
    public final AutoTotem autoTotem = new AutoTotem();
    public final NoFriendsDamage noFriendsDamage = new NoFriendsDamage();
    public final Velocity velocity = new Velocity();

    public final List<Module> all = List.of(aimAssist, triggerBot, aura, autoTotem, noFriendsDamage, velocity);

    public void tick() {
        for (Module m : all) {
            if (m.enabled) m.onTick();
        }
    }
}

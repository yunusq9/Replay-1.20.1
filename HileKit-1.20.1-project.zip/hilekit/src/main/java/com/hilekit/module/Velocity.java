package com.hilekit.module;

public class Velocity extends Module {
    public Velocity() {
        super("Velocity");
    }
}

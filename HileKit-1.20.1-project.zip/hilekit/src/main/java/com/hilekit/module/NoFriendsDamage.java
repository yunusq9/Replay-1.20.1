package com.hilekit.module;

public class NoFriendsDamage extends Module {
    public NoFriendsDamage() {
        super("No Friends Damage");
    }
}

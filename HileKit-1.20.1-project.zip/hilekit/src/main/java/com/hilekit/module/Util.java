package com.hilekit.module;

import com.hilekit.FriendManager;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;

public class Util {
    public static boolean validTarget(MinecraftClient mc, Entity e, double range, boolean playersOnly) {
        if (mc.player == null || e == mc.player || !(e instanceof LivingEntity le)) return false;
        if (!le.isAlive()) return false;
        if (playersOnly && !(e instanceof PlayerEntity)) return false;
        if (e instanceof PlayerEntity p) {
            if (FriendManager.isFriend(p.getGameProfile().getName())) return false;
            if (p.isSpectator()) return false;
        }
        return mc.player.distanceTo(e) <= range;
    }

    public static Entity nearest(MinecraftClient mc, double range, boolean playersOnly) {
        Entity best = null;
        double bestDist = Double.MAX_VALUE;
        for (Entity e : mc.world.getEntities()) {
            if (!validTarget(mc, e, range, playersOnly)) continue;
            double d = mc.player.squaredDistanceTo(e);
            if (d < bestDist) {
                bestDist = d;
                best = e;
            }
        }
        return best;
    }

    public static void attack(MinecraftClient mc, Entity e) {
        mc.interactionManager.attackEntity(mc.player, e);
        mc.player.swingHand(net.minecraft.util.Hand.MAIN_HAND);
    }
}

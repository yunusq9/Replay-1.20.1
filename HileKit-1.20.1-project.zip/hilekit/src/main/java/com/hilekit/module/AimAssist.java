package com.hilekit.module;

import net.minecraft.entity.Entity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

public class AimAssist extends Module {
    public final Setting range = add("Menzil", 2, 8, 4.5);
    public final Setting speed = add("Hız", 1, 20, 6);

    public AimAssist() {
        super("Aim Assist");
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null || mc.currentScreen != null) return;
        Entity t = Util.nearest(mc, range.value, true);
        if (t == null) return;
        Vec3d eye = mc.player.getEyePos();
        Vec3d to = t.getPos().add(0, t.getHeight() * 0.85, 0);
        double dx = to.x - eye.x, dy = to.y - eye.y, dz = to.z - eye.z;
        float yaw = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
        float pitch = (float) -Math.toDegrees(Math.atan2(dy, Math.sqrt(dx * dx + dz * dz)));
        float dyaw = MathHelper.wrapDegrees(yaw - mc.player.getYaw());
        float dpitch = pitch - mc.player.getPitch();
        float max = (float) speed.value;
        mc.player.setYaw(mc.player.getYaw() + MathHelper.clamp(dyaw, -max, max));
        mc.player.setPitch(MathHelper.clamp(mc.player.getPitch() + MathHelper.clamp(dpitch, -max, max), -90f, 90f));
    }
}

package com.hilekit.module;

import net.minecraft.client.MinecraftClient;

import java.util.ArrayList;
import java.util.List;

public abstract class Module {
    public final String name;
    public boolean enabled = false;
    public final List<Setting> settings = new ArrayList<>();
    protected final MinecraftClient mc = MinecraftClient.getInstance();

    protected Module(String name) {
        this.name = name;
    }

    protected Setting add(String name, double min, double max, double value) {
        Setting s = new Setting(name, min, max, value);
        settings.add(s);
        return s;
    }

    public void toggle() {
        enabled = !enabled;
    }

    public void onTick() {
    }
}

package com.hilekit.module;

import net.minecraft.entity.Entity;
import net.minecraft.util.hit.EntityHitResult;

public class TriggerBot extends Module {
    public final Setting cooldown = add("Bekleme", 0.5, 1.0, 0.9);

    public TriggerBot() {
        super("Trigger Bot");
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null || mc.currentScreen != null) return;
        if (!(mc.crosshairTarget instanceof EntityHitResult hit)) return;
        Entity e = hit.getEntity();
        if (!Util.validTarget(mc, e, 6.0, false)) return;
        if (mc.player.getAttackCooldownProgress(0.5f) < cooldown.value) return;
        Util.attack(mc, e);
    }
}
